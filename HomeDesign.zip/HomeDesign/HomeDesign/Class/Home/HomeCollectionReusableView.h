//
//  HomeCollectionReusableView.h
//  HomeDesign
//
//  Created by apple on 15/11/14.
//  Copyright (c) 2015年 四川青创智和网络科技有限公司. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HomeCollectionReusableView : UICollectionReusableView

@property (nonatomic, strong) UIView *headerView;
@property (nonatomic, strong) UIView *adImageView;

@end
