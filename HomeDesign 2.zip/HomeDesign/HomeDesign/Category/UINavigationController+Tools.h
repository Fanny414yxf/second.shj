//
//  UINavigationController+YRBackGesture.h
//  Mark
//
//  Created by 王晓宇 on 14-7-8.
//  Copyright (c) 2014年 王晓宇. All rights reserved.
//

/*!
 *	@class	let NavigationController support slide to right to back to previous VC
 */
#import <UIKit/UIKit.h>

#define BackGestureOffsetXToBack 80//>80 show pre vc

@interface UINavigationController (Tools)
/*!
 *	@brief	Default is NO;
 *  @note need call this after ViewDidLoad otherwise not work;
 */
@property (assign,nonatomic) BOOL enableBackGesture;

@end
