//
//  CityTableViewCell.h
//  HomeDesign
//
//  Created by 杨晓芬 on 15/11/20.
//  Copyright © 2015年 四川青创智和网络科技有限公司. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CityModel.h"

@interface CityTableViewCell : UITableViewCell

@property (nonatomic, strong) UIButton *chooseBtn;

@end
