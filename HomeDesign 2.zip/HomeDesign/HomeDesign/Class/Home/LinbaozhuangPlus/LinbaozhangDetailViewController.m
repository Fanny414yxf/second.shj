//
//  LinbaozhangDetailViewController.m
//  HomeDesign
//
//  Created by 杨晓芬 on 15/12/14.
//  Copyright © 2015年 四川青创智和网络科技有限公司. All rights reserved.
//

#import "LinbaozhangDetailViewController.h"

@interface LinbaozhangDetailViewController ()

@end

@implementation LinbaozhangDetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.url = HAIKUANDETAIL_HTML;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
