//
//  FLEXClassesTableViewController.h
//  Flipboard
//
//  Created by Ryan Olson on 2014-05-03.
//  Copyright (c) 2014 Flipboard. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FLEXClassesTableViewController : UITableViewController

@property (nonatomic, copy) NSString *binaryImageName;

@end
